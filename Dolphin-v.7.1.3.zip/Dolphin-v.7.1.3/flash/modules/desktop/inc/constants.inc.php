<?php
/***************************************************************************
*
* IMPORTANT: This is a commercial product made by BoonEx Ltd. and cannot be modified for other than personal usage.
* This product cannot be redistributed for free or a fee without written permission from BoonEx Ltd.
* This notice may not be removed from the source code.
*
***************************************************************************/

$aInfo = array(
    'version' => "7.1.0000",
    'title' => "Desktop",
    'code' => "desktop_7.1.0000",
    'author' => "Boonex",
    'authorUrl' => "http://www.boonex.com/"
);
$aModules = array();
