<?php
require_once("../../../../inc/header.inc.php");
readfile($sFileErrorPath);
